import { MainLayout } from "@/components/main-layout"
import { NotificationTester } from "@/components/notification-tester"
import { Button } from "@/components/ui/button"
import { Zap } from "lucide-react"
import { simulateAutoNotifications } from "@/lib/auto-notification-service"

export default function VerificarNotificacoesPage() {
  async function handleSimulateNotifications() {
    "use server"
    await simulateAutoNotifications()
  }

  return (
    <MainLayout>
      <div className="container mx-auto py-6">
        <h1 className="text-3xl font-bold mb-2">Verificar Notificações</h1>
        <p className="text-muted-foreground mb-6">
          Teste e verifique se as notificações estão sendo enviadas corretamente
        </p>

        <div className="mb-6">
          <form action={handleSimulateNotifications}>
            <Button type="submit" className="flex items-center">
              <Zap className="mr-2 h-4 w-4" />
              Simular Notificações Automáticas
            </Button>
          </form>
          <p className="text-sm text-muted-foreground mt-2">
            Clique no botão acima para simular o envio de notificações automáticas com base nas suas configurações
          </p>
        </div>

        <NotificationTester />
      </div>
    </MainLayout>
  )
}
