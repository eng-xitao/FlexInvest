import { MainLayout } from "@/components/main-layout"
import { TelegramConfig } from "@/components/telegram-config"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { Card, CardContent } from "@/components/ui/card"
import { Bell, Globe, User, Paintbrush } from "lucide-react"

export default function ConfiguracoesPage() {
  return (
    <MainLayout>
      <div className="container mx-auto py-6">
        <h1 className="text-3xl font-bold mb-2">Configurações</h1>
        <p className="text-muted-foreground mb-6">Configurações gerais do sistema</p>

        <Tabs defaultValue="notificacoes" className="w-full">
          <TabsList className="grid w-full grid-cols-4">
            <TabsTrigger value="notificacoes" className="flex items-center">
              <Bell className="h-4 w-4 mr-2" />
              Notificações
            </TabsTrigger>
            <TabsTrigger value="apis" className="flex items-center">
              <Globe className="h-4 w-4 mr-2" />
              APIs
            </TabsTrigger>
            <TabsTrigger value="conta" className="flex items-center">
              <User className="h-4 w-4 mr-2" />
              Conta
            </TabsTrigger>
            <TabsTrigger value="aparencia" className="flex items-center">
              <Paintbrush className="h-4 w-4 mr-2" />
              Aparência
            </TabsTrigger>
          </TabsList>

          <TabsContent value="notificacoes" className="mt-6">
            <Card>
              <CardContent className="pt-6">
                <TelegramConfig />
              </CardContent>
            </Card>
          </TabsContent>

          <TabsContent value="apis" className="mt-6">
            <Card>
              <CardContent className="pt-6">
                <h3 className="text-lg font-medium mb-4">Configurações de APIs</h3>
                <p className="text-muted-foreground">Configure as APIs de exchanges e outros serviços externos.</p>
              </CardContent>
            </Card>
          </TabsContent>

          <TabsContent value="conta" className="mt-6">
            <Card>
              <CardContent className="pt-6">
                <h3 className="text-lg font-medium mb-4">Configurações de Conta</h3>
                <p className="text-muted-foreground">Gerencie suas informações de conta e preferências.</p>
              </CardContent>
            </Card>
          </TabsContent>

          <TabsContent value="aparencia" className="mt-6">
            <Card>
              <CardContent className="pt-6">
                <h3 className="text-lg font-medium mb-4">Configurações de Aparência</h3>
                <p className="text-muted-foreground">Personalize a aparência e o tema da aplicação.</p>
              </CardContent>
            </Card>
          </TabsContent>
        </Tabs>
      </div>
    </MainLayout>
  )
}
