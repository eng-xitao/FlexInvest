"use client"

import { useState, useEffect } from "react"
import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from "@/components/ui/card"
import { Tabs, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { Button } from "@/components/ui/button"
import { CoinSelector } from "@/components/coin-selector"
import { fetchMarketData, calculateSMA, calculateRSI, calculateMACD } from "@/lib/trading-utils"
import { XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer, AreaChart, Area, BarChart, Bar } from "recharts"
import { ArrowUpRight, ArrowDownRight, TrendingUp, Wallet } from "lucide-react"

export function DashboardContent() {
  const [selectedCoin, setSelectedCoin] = useState("bitcoin")
  const [marketData, setMarketData] = useState([])
  const [isLoading, setIsLoading] = useState(true)
  const [timeframe, setTimeframe] = useState("7d")
  const [latestPrice, setLatestPrice] = useState(0)
  const [priceChange, setPriceChange] = useState({ value: 0, percentage: 0 })
  const [indicators, setIndicators] = useState({
    sma20: 0,
    rsi14: 0,
    macd: { value: 0, signal: 0, histogram: 0 },
  })
  const [recentSignals, setRecentSignals] = useState([
    { id: 1, coin: "BTC", type: "buy", price: 52380.45, time: "2 horas atrás", reason: "Cruzamento de médias móveis" },
    { id: 2, coin: "ETH", type: "sell", price: 2890.12, time: "5 horas atrás", reason: "RSI sobrecomprado" },
    { id: 3, coin: "SOL", type: "buy", price: 138.75, time: "1 dia atrás", reason: "Suporte em tendência de alta" },
  ])

  const [portfolioValue, setPortfolioValue] = useState(10250.75)
  const [portfolioChange, setPortfolioChange] = useState(3.2)
  const [openPositions, setOpenPositions] = useState([
    { id: 1, coin: "BTC", amount: 0.05, entryPrice: 51200, currentPrice: 52380.45, pnl: 59.02, pnlPercentage: 2.3 },
    { id: 2, coin: "ETH", amount: 1.2, entryPrice: 2750, currentPrice: 2890.12, pnl: 168.14, pnlPercentage: 5.1 },
  ])

  useEffect(() => {
    const loadMarketData = async () => {
      setIsLoading(true)
      try {
        const data = await fetchMarketData(selectedCoin)
        setMarketData(data)

        if (data.length > 0) {
          // Calcular preço atual e variação
          const currentPrice = data[data.length - 1].price
          const previousPrice = data[data.length - 2].price
          const priceChangeValue = currentPrice - previousPrice
          const priceChangePercentage = (priceChangeValue / previousPrice) * 100

          setLatestPrice(currentPrice)
          setPriceChange({
            value: priceChangeValue,
            percentage: priceChangePercentage,
          })

          // Calcular indicadores
          const sma20Data = calculateSMA(data, 20)
          const rsi14Data = calculateRSI(data, 14)
          const macdData = calculateMACD(data, 12, 26, 9)

          setIndicators({
            sma20: sma20Data[sma20Data.length - 1],
            rsi14: rsi14Data[rsi14Data.length - 1],
            macd: {
              value: macdData.macdLine[macdData.macdLine.length - 1],
              signal: macdData.signalLine[macdData.signalLine.length - 1],
              histogram: macdData.histogram[macdData.histogram.length - 1],
            },
          })
        }
      } catch (error) {
        console.error("Erro ao carregar dados:", error)
      } finally {
        setIsLoading(false)
      }
    }

    loadMarketData()
    // Atualiza a cada 5 minutos
    const interval = setInterval(loadMarketData, 5 * 60 * 1000)
    return () => clearInterval(interval)
  }, [selectedCoin])

  // Filtrar dados com base no timeframe selecionado
  const filteredData = () => {
    if (!marketData.length) return []

    const now = new Date()
    const cutoffDate = new Date()

    switch (timeframe) {
      case "24h":
        cutoffDate.setDate(now.getDate() - 1)
        break
      case "7d":
        cutoffDate.setDate(now.getDate() - 7)
        break
      case "30d":
        cutoffDate.setDate(now.getDate() - 30)
        break
      case "90d":
        cutoffDate.setDate(now.getDate() - 90)
        break
      default:
        return marketData
    }

    return marketData.filter((item) => new Date(item.date) >= cutoffDate)
  }

  // Formatar dados para o gráfico
  const chartData = filteredData().map((item) => ({
    date: new Date(item.date).toLocaleDateString(),
    price: item.price,
    volume: item.volume / 1000000, // Converter para milhões
  }))

  return (
    <div className="space-y-4">
      <div className="flex flex-col md:flex-row justify-between items-start md:items-center gap-4 mb-6">
        <div>
          <h2 className="text-3xl font-bold">Dashboard</h2>
          <p className="text-muted-foreground">Visão geral do mercado e suas operações</p>
        </div>
        <CoinSelector selectedCoin={selectedCoin} onSelectCoin={setSelectedCoin} isLoading={isLoading} />
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4">
        <Card>
          <CardHeader className="pb-2">
            <CardTitle className="text-sm font-medium">Preço Atual</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">
              ${latestPrice.toLocaleString("pt-BR", { minimumFractionDigits: 2, maximumFractionDigits: 2 })}
            </div>
            <div
              className={`flex items-center text-sm ${priceChange.percentage >= 0 ? "text-green-500" : "text-red-500"}`}
            >
              {priceChange.percentage >= 0 ? (
                <ArrowUpRight className="h-4 w-4 mr-1" />
              ) : (
                <ArrowDownRight className="h-4 w-4 mr-1" />
              )}
              <span>
                {priceChange.percentage >= 0 ? "+" : ""}
                {priceChange.percentage.toFixed(2)}%
              </span>
            </div>
          </CardContent>
        </Card>

        <Card>
          <CardHeader className="pb-2">
            <CardTitle className="text-sm font-medium">RSI (14)</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">{indicators.rsi14 ? indicators.rsi14.toFixed(2) : "N/A"}</div>
            <div className="text-sm text-muted-foreground">
              {indicators.rsi14 > 70 ? "Sobrecomprado" : indicators.rsi14 < 30 ? "Sobrevendido" : "Neutro"}
            </div>
          </CardContent>
        </Card>

        <Card>
          <CardHeader className="pb-2">
            <CardTitle className="text-sm font-medium">MACD</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">{indicators.macd.value ? indicators.macd.value.toFixed(2) : "N/A"}</div>
            <div className={`text-sm ${indicators.macd.histogram > 0 ? "text-green-500" : "text-red-500"}`}>
              Histograma: {indicators.macd.histogram ? indicators.macd.histogram.toFixed(2) : "N/A"}
            </div>
          </CardContent>
        </Card>

        <Card>
          <CardHeader className="pb-2">
            <CardTitle className="text-sm font-medium">Valor do Portfólio</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">
              ${portfolioValue.toLocaleString("pt-BR", { minimumFractionDigits: 2, maximumFractionDigits: 2 })}
            </div>
            <div className={`flex items-center text-sm ${portfolioChange >= 0 ? "text-green-500" : "text-red-500"}`}>
              {portfolioChange >= 0 ? (
                <ArrowUpRight className="h-4 w-4 mr-1" />
              ) : (
                <ArrowDownRight className="h-4 w-4 mr-1" />
              )}
              <span>
                {portfolioChange >= 0 ? "+" : ""}
                {portfolioChange.toFixed(2)}%
              </span>
            </div>
          </CardContent>
        </Card>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-4">
        <Card className="lg:col-span-2">
          <CardHeader>
            <div className="flex items-center justify-between">
              <CardTitle>Gráfico de Preço</CardTitle>
              <Tabs defaultValue="7d" value={timeframe} onValueChange={setTimeframe}>
                <TabsList>
                  <TabsTrigger value="24h">24h</TabsTrigger>
                  <TabsTrigger value="7d">7d</TabsTrigger>
                  <TabsTrigger value="30d">30d</TabsTrigger>
                  <TabsTrigger value="90d">90d</TabsTrigger>
                </TabsList>
              </Tabs>
            </div>
          </CardHeader>
          <CardContent>
            {isLoading ? (
              <div className="flex justify-center items-center h-[300px]">
                <div className="animate-spin rounded-full h-8 w-8 border-b-2 border-primary"></div>
              </div>
            ) : chartData.length > 0 ? (
              <div className="h-[300px]">
                <ResponsiveContainer width="100%" height="100%">
                  <AreaChart data={chartData}>
                    <defs>
                      <linearGradient id="colorPrice" x1="0" y1="0" x2="0" y2="1">
                        <stop offset="5%" stopColor="#8884d8" stopOpacity={0.8} />
                        <stop offset="95%" stopColor="#8884d8" stopOpacity={0} />
                      </linearGradient>
                    </defs>
                    <CartesianGrid strokeDasharray="3 3" />
                    <XAxis dataKey="date" />
                    <YAxis domain={["auto", "auto"]} />
                    <Tooltip />
                    <Area type="monotone" dataKey="price" stroke="#8884d8" fillOpacity={1} fill="url(#colorPrice)" />
                  </AreaChart>
                </ResponsiveContainer>
              </div>
            ) : (
              <div className="flex justify-center items-center h-[300px]">
                <p>Nenhum dado disponível</p>
              </div>
            )}
          </CardContent>
        </Card>

        <Card>
          <CardHeader>
            <CardTitle>Sinais Recentes</CardTitle>
            <CardDescription>Últimos sinais de trading gerados</CardDescription>
          </CardHeader>
          <CardContent>
            <div className="space-y-4">
              {recentSignals.map((signal) => (
                <div key={signal.id} className="flex items-start space-x-3 border-b pb-3 last:border-0">
                  <div
                    className={`p-2 rounded-full ${signal.type === "buy" ? "bg-green-100 dark:bg-green-900" : "bg-red-100 dark:bg-red-900"}`}
                  >
                    {signal.type === "buy" ? (
                      <TrendingUp className="h-4 w-4 text-green-600 dark:text-green-400" />
                    ) : (
                      <TrendingUp className="h-4 w-4 text-red-600 dark:text-red-400" />
                    )}
                  </div>
                  <div className="flex-1">
                    <div className="flex justify-between">
                      <h4 className="font-medium">{signal.coin}</h4>
                      <span
                        className={`text-sm ${signal.type === "buy" ? "text-green-600 dark:text-green-400" : "text-red-600 dark:text-red-400"}`}
                      >
                        {signal.type.toUpperCase()}
                      </span>
                    </div>
                    <p className="text-sm text-muted-foreground">
                      ${signal.price.toLocaleString("pt-BR", { minimumFractionDigits: 2, maximumFractionDigits: 2 })}
                    </p>
                    <div className="flex justify-between mt-1">
                      <span className="text-xs text-muted-foreground">{signal.reason}</span>
                      <span className="text-xs text-muted-foreground">{signal.time}</span>
                    </div>
                  </div>
                </div>
              ))}
            </div>
          </CardContent>
          <CardFooter>
            <Button variant="outline" className="w-full">
              Ver Todos os Sinais
            </Button>
          </CardFooter>
        </Card>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-2 gap-4">
        <Card>
          <CardHeader>
            <CardTitle>Volume de Negociação</CardTitle>
            <CardDescription>Volume diário em milhões de USD</CardDescription>
          </CardHeader>
          <CardContent>
            <div className="h-[250px]">
              {chartData.length > 0 ? (
                <ResponsiveContainer width="100%" height="100%">
                  <BarChart data={chartData}>
                    <CartesianGrid strokeDasharray="3 3" />
                    <XAxis dataKey="date" />
                    <YAxis />
                    <Tooltip />
                    <Bar dataKey="volume" fill="#8884d8" name="Volume (milhões USD)" />
                  </BarChart>
                </ResponsiveContainer>
              ) : (
                <div className="flex justify-center items-center h-full">
                  <p>Nenhum dado disponível</p>
                </div>
              )}
            </div>
          </CardContent>
        </Card>

        <Card>
          <CardHeader>
            <CardTitle>Posições Abertas</CardTitle>
            <CardDescription>Suas posições de trading atuais</CardDescription>
          </CardHeader>
          <CardContent>
            {openPositions.length > 0 ? (
              <div className="space-y-4">
                {openPositions.map((position) => (
                  <div key={position.id} className="flex items-center justify-between border-b pb-3 last:border-0">
                    <div className="flex items-center space-x-3">
                      <div className="p-2 rounded-full bg-blue-100 dark:bg-blue-900">
                        <Wallet className="h-4 w-4 text-blue-600 dark:text-blue-400" />
                      </div>
                      <div>
                        <h4 className="font-medium">{position.coin}</h4>
                        <p className="text-sm text-muted-foreground">{position.amount} unidades</p>
                      </div>
                    </div>
                    <div className="text-right">
                      <div
                        className={`font-medium ${position.pnl >= 0 ? "text-green-600 dark:text-green-400" : "text-red-600 dark:text-red-400"}`}
                      >
                        ${position.pnl.toFixed(2)} ({position.pnlPercentage >= 0 ? "+" : ""}
                        {position.pnlPercentage.toFixed(2)}%)
                      </div>
                      <p className="text-sm text-muted-foreground">
                        $
                        {position.entryPrice.toLocaleString("pt-BR", {
                          minimumFractionDigits: 2,
                          maximumFractionDigits: 2,
                        })}{" "}
                        → $
                        {position.currentPrice.toLocaleString("pt-BR", {
                          minimumFractionDigits: 2,
                          maximumFractionDigits: 2,
                        })}
                      </p>
                    </div>
                  </div>
                ))}
              </div>
            ) : (
              <div className="flex flex-col items-center justify-center py-6 text-center">
                <Wallet className="h-10 w-10 text-muted-foreground mb-2" />
                <h3 className="text-lg font-medium">Nenhuma posição aberta</h3>
                <p className="text-sm text-muted-foreground mt-1">
                  Você não tem posições de trading abertas no momento.
                </p>
              </div>
            )}
          </CardContent>
          <CardFooter>
            <Button variant="outline" className="w-full">
              Gerenciar Posições
            </Button>
          </CardFooter>
        </Card>
      </div>
    </div>
  )
}
