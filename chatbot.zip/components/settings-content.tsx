"use client"

import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { TelegramConfig } from "@/components/telegram-config"
import { Button } from "@/components/ui/button"
import Link from "next/link"
import { MessageSquare } from "lucide-react"

export function SettingsContent() {
  return (
    <div className="container mx-auto py-6">
      <div className="mb-6">
        <h1 className="text-3xl font-bold">Configurações</h1>
        <p className="text-muted-foreground">Configurações gerais do sistema</p>
      </div>

      <Tabs defaultValue="notifications">
        <TabsList className="mb-4">
          <TabsTrigger value="notifications">Notificações</TabsTrigger>
          <TabsTrigger value="api">APIs de Exchanges</TabsTrigger>
          <TabsTrigger value="account">Conta</TabsTrigger>
          <TabsTrigger value="appearance">Aparência</TabsTrigger>
        </TabsList>

        <TabsContent value="notifications">
          <div className="grid gap-6 md:grid-cols-2">
            <Card>
              <CardHeader>
                <CardTitle>Telegram</CardTitle>
                <CardDescription>Configure seu bot do Telegram para receber alertas</CardDescription>
              </CardHeader>
              <CardContent>
                <TelegramConfig />
                <div className="mt-4">
                  <Button asChild variant="outline" className="w-full">
                    <Link href="/telegram-messages">
                      <MessageSquare className="mr-2 h-4 w-4" />
                      Visualizar Formatos de Mensagem
                    </Link>
                  </Button>
                </div>
              </CardContent>
            </Card>

            <Card>
              <CardHeader>
                <CardTitle>Outros Canais</CardTitle>
                <CardDescription>Configurar notificações adicionais</CardDescription>
              </CardHeader>
              <CardContent>
                <p className="text-sm text-muted-foreground">Mais opções de notificação serão adicionadas em breve.</p>
                <div className="mt-4 space-y-4">
                  <div className="flex items-center space-x-2 opacity-50">
                    <input type="checkbox" id="email" disabled />
                    <label htmlFor="email" className="text-sm">
                      Email
                    </label>
                  </div>
                  <div className="flex items-center space-x-2 opacity-50">
                    <input type="checkbox" id="discord" disabled />
                    <label htmlFor="discord" className="text-sm">
                      Discord
                    </label>
                  </div>
                  <div className="flex items-center space-x-2 opacity-50">
                    <input type="checkbox" id="whatsapp" disabled />
                    <label htmlFor="whatsapp" className="text-sm">
                      WhatsApp
                    </label>
                  </div>
                </div>
              </CardContent>
            </Card>
          </div>
        </TabsContent>

        <TabsContent value="api">
          <Card>
            <CardHeader>
              <CardTitle>Configurações de API</CardTitle>
              <CardDescription>Conecte-se às exchanges para obter dados em tempo real</CardDescription>
            </CardHeader>
            <CardContent>
              <p className="text-sm text-muted-foreground mb-4">
                Configure suas chaves de API para acessar dados em tempo real das exchanges.
              </p>
              {/* Conteúdo de configuração de API será adicionado aqui */}
            </CardContent>
          </Card>
        </TabsContent>

        <TabsContent value="account">
          <Card>
            <CardHeader>
              <CardTitle>Configurações de Conta</CardTitle>
              <CardDescription>Gerencie suas informações de conta</CardDescription>
            </CardHeader>
            <CardContent>
              <p className="text-sm text-muted-foreground">Configurações de conta serão adicionadas em breve.</p>
            </CardContent>
          </Card>
        </TabsContent>

        <TabsContent value="appearance">
          <Card>
            <CardHeader>
              <CardTitle>Aparência</CardTitle>
              <CardDescription>Personalize a aparência do aplicativo</CardDescription>
            </CardHeader>
            <CardContent>
              <p className="text-sm text-muted-foreground">Configurações de aparência serão adicionadas em breve.</p>
            </CardContent>
          </Card>
        </TabsContent>
      </Tabs>
    </div>
  )
}
