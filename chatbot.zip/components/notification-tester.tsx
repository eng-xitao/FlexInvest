"use client"

import { useState } from "react"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from "@/components/ui/card"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Textarea } from "@/components/ui/textarea"
import { Badge } from "@/components/ui/badge"
import { Loader2, Send, RefreshCw, CheckCircle, XCircle } from "lucide-react"
import { useToast } from "@/components/ui/use-toast"
import { sendTelegramNotification, testTelegramConnection } from "@/lib/notification-service"
import { getConfig } from "@/lib/config-service"

export function NotificationTester() {
  const { toast } = useToast()
  const [activeTab, setActiveTab] = useState("testar")
  const [isLoading, setIsLoading] = useState(false)
  const [isTesting, setIsTesting] = useState(false)
  const [isDiagnosing, setIsDiagnosing] = useState(false)

  const [telegramConfig, setTelegramConfig] = useState({
    botToken: "",
    chatId: "",
  })

  const [testMessage, setTestMessage] = useState({
    type: "signal",
    message: `🚨 Alerta de Trading - FlexInvest

📊 Moeda: BTC/USD
💲 Preço Atual: R$250000.00
🟢 Ação: COMPRA
📊 Variação 1h: 0.58%
✅ Confiabilidade: 75%

🕒 Horário de Entrada: ${new Date().toLocaleTimeString()}
⏳ Expiração: Entrada válida por 3 minutos

📝 Justificativa: MACD aponta tendência de alta | Média móvel cruzada com volume relevante

🤖 Sinal gerado automaticamente por FlexInvest`,
  })

  const [notificationHistory, setNotificationHistory] = useState([
    {
      id: "1",
      type: "signal",
      message: "Sinal de compra BTC",
      timestamp: new Date(Date.now() - 3600000),
      status: "success",
    },
    {
      id: "2",
      type: "alert",
      message: "Alerta de preço ETH",
      timestamp: new Date(Date.now() - 7200000),
      status: "success",
    },
    {
      id: "3",
      type: "error",
      message: "Erro de conexão",
      timestamp: new Date(Date.now() - 86400000),
      status: "failed",
      error: "Não foi possível conectar à API",
    },
  ])

  const [diagnosticResults, setDiagnosticResults] = useState({
    configComplete: null,
    internetConnection: null,
    telegramApi: null,
  })

  // Carregar configurações ao iniciar
  useState(() => {
    async function loadConfig() {
      try {
        setIsLoading(true)
        const config = await getConfig("telegram")
        if (config) {
          setTelegramConfig({
            botToken: config.botToken || "",
            chatId: config.chatId || "",
          })
        }
      } catch (error) {
        console.error("Erro ao carregar configurações:", error)
      } finally {
        setIsLoading(false)
      }
    }

    loadConfig()
  })

  const handleSendTest = async () => {
    if (!telegramConfig.botToken || !telegramConfig.chatId) {
      toast({
        title: "Configuração incompleta",
        description: "Por favor, preencha o Token do Bot e o ID do Chat antes de testar.",
        variant: "destructive",
      })
      return
    }

    setIsTesting(true)

    try {
      const result = await sendTelegramNotification(telegramConfig.botToken, telegramConfig.chatId, testMessage.message)

      // Adicionar ao histórico
      const newNotification = {
        id: Date.now().toString(),
        type: testMessage.type,
        message: testMessage.message.substring(0, 50) + "...",
        timestamp: new Date(),
        status: result.success ? "success" : "failed",
        error: result.error,
      }

      setNotificationHistory([newNotification, ...notificationHistory])

      if (result.success) {
        toast({
          title: "Notificação enviada",
          description: "A mensagem de teste foi enviada com sucesso para o Telegram",
        })
      } else {
        toast({
          title: "Falha no envio",
          description: result.error || "Não foi possível enviar a mensagem de teste",
          variant: "destructive",
        })
      }
    } catch (error) {
      toast({
        title: "Erro",
        description: "Ocorreu um erro ao enviar a notificação",
        variant: "destructive",
      })
    } finally {
      setIsTesting(false)
    }
  }

  const runDiagnostic = async () => {
    setIsDiagnosing(true)
    setDiagnosticResults({
      configComplete: null,
      internetConnection: null,
      telegramApi: null,
    })

    // Verificar se a configuração está completa
    const configComplete = !!(telegramConfig.botToken && telegramConfig.chatId)
    setDiagnosticResults((prev) => ({ ...prev, configComplete }))

    // Verificar conexão com a internet
    try {
      const internetResponse = await fetch("https://www.google.com", { method: "HEAD" })
      setDiagnosticResults((prev) => ({ ...prev, internetConnection: internetResponse.ok }))
    } catch (error) {
      setDiagnosticResults((prev) => ({ ...prev, internetConnection: false }))
    }

    // Verificar API do Telegram
    if (telegramConfig.botToken) {
      try {
        const apiResult = await testTelegramConnection(telegramConfig.botToken)
        setDiagnosticResults((prev) => ({ ...prev, telegramApi: apiResult.success }))
      } catch (error) {
        setDiagnosticResults((prev) => ({ ...prev, telegramApi: false }))
      }
    } else {
      setDiagnosticResults((prev) => ({ ...prev, telegramApi: false }))
    }

    setIsDiagnosing(false)
  }

  const resendNotification = async (id) => {
    const notification = notificationHistory.find((n) => n.id === id)
    if (!notification) return

    // Implementação simplificada - em um ambiente real, você recuperaria a mensagem completa
    toast({
      title: "Reenviando notificação",
      description: "A funcionalidade de reenvio está em implementação",
    })
  }

  const getMessageTypeOptions = () => [
    { value: "signal", label: "Sinal de Trading" },
    { value: "alert", label: "Alerta de Preço" },
    { value: "order", label: "Ordem Executada" },
    { value: "flash", label: "Sinal Flash" },
    { value: "menu", label: "Menu Principal" },
    { value: "error", label: "Erro" },
  ]

  const getStatusBadge = (status) => {
    switch (status) {
      case "success":
        return <Badge className="bg-green-500">Enviado</Badge>
      case "failed":
        return <Badge variant="destructive">Falhou</Badge>
      case "pending":
        return <Badge variant="outline">Pendente</Badge>
      default:
        return <Badge variant="secondary">Desconhecido</Badge>
    }
  }

  const getDiagnosticIcon = (status) => {
    if (status === null) return <Loader2 className="h-5 w-5 animate-spin text-muted-foreground" />
    return status ? <CheckCircle className="h-5 w-5 text-green-500" /> : <XCircle className="h-5 w-5 text-red-500" />
  }

  return (
    <Card>
      <CardHeader>
        <CardTitle>Verificador de Notificações</CardTitle>
        <CardDescription>Teste e verifique se as notificações estão sendo enviadas corretamente</CardDescription>
      </CardHeader>
      <CardContent>
        <Tabs value={activeTab} onValueChange={setActiveTab}>
          <TabsList className="grid w-full grid-cols-3">
            <TabsTrigger value="testar">Testar Envio</TabsTrigger>
            <TabsTrigger value="historico">Histórico</TabsTrigger>
            <TabsTrigger value="diagnostico">Diagnóstico</TabsTrigger>
          </TabsList>

          <TabsContent value="testar" className="space-y-4 mt-4">
            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              <div className="space-y-2">
                <Label htmlFor="bot-token">Token do Bot</Label>
                <Input
                  id="bot-token"
                  type="password"
                  placeholder="1234567890:ABCDEFGHIJKLMNOPQRSTUVWXYZ"
                  value={telegramConfig.botToken}
                  onChange={(e) => setTelegramConfig((prev) => ({ ...prev, botToken: e.target.value }))}
                />
              </div>

              <div className="space-y-2">
                <Label htmlFor="chat-id">ID do Chat</Label>
                <Input
                  id="chat-id"
                  placeholder="123456789"
                  value={telegramConfig.chatId}
                  onChange={(e) => setTelegramConfig((prev) => ({ ...prev, chatId: e.target.value }))}
                />
              </div>
            </div>

            <div className="space-y-2">
              <Label htmlFor="message-type">Tipo de Mensagem</Label>
              <Select
                value={testMessage.type}
                onValueChange={(value) => setTestMessage((prev) => ({ ...prev, type: value }))}
              >
                <SelectTrigger id="message-type">
                  <SelectValue placeholder="Selecione o tipo de mensagem" />
                </SelectTrigger>
                <SelectContent>
                  {getMessageTypeOptions().map((option) => (
                    <SelectItem key={option.value} value={option.value}>
                      {option.label}
                    </SelectItem>
                  ))}
                </SelectContent>
              </Select>
            </div>

            <div className="space-y-2">
              <Label htmlFor="message-content">Conteúdo da Mensagem</Label>
              <Textarea
                id="message-content"
                placeholder="Digite a mensagem a ser enviada"
                value={testMessage.message}
                onChange={(e) => setTestMessage((prev) => ({ ...prev, message: e.target.value }))}
                rows={10}
                className="font-mono text-sm"
              />
            </div>
          </TabsContent>

          <TabsContent value="historico" className="mt-4">
            {notificationHistory.length > 0 ? (
              <div className="space-y-4">
                {notificationHistory.map((notification) => (
                  <div key={notification.id} className="flex items-start justify-between border-b pb-3">
                    <div>
                      <div className="flex items-center gap-2">
                        <h4 className="font-medium">
                          {notification.type.charAt(0).toUpperCase() + notification.type.slice(1)}
                        </h4>
                        {getStatusBadge(notification.status)}
                      </div>
                      <p className="text-sm text-muted-foreground mt-1">{notification.message}</p>
                      <p className="text-xs text-muted-foreground mt-1">{notification.timestamp.toLocaleString()}</p>
                      {notification.error && <p className="text-xs text-red-500 mt-1">{notification.error}</p>}
                    </div>
                    {notification.status === "failed" && (
                      <Button variant="outline" size="sm" onClick={() => resendNotification(notification.id)}>
                        <RefreshCw className="h-3 w-3 mr-1" />
                        Reenviar
                      </Button>
                    )}
                  </div>
                ))}
              </div>
            ) : (
              <div className="text-center py-8 text-muted-foreground">
                <p>Nenhuma notificação no histórico</p>
              </div>
            )}
          </TabsContent>

          <TabsContent value="diagnostico" className="mt-4">
            <div className="space-y-6">
              <div className="flex justify-between items-center">
                <h3 className="text-lg font-medium">Diagnóstico do Sistema de Notificações</h3>
                <Button variant="outline" size="sm" onClick={runDiagnostic} disabled={isDiagnosing}>
                  {isDiagnosing ? (
                    <>
                      <Loader2 className="h-4 w-4 mr-2 animate-spin" />
                      Executando...
                    </>
                  ) : (
                    <>
                      <RefreshCw className="h-4 w-4 mr-2" />
                      Executar Diagnóstico
                    </>
                  )}
                </Button>
              </div>

              <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
                <Card>
                  <CardContent className="pt-6">
                    <div className="flex justify-between items-center">
                      <h4 className="font-medium">Configuração</h4>
                      {getDiagnosticIcon(diagnosticResults.configComplete)}
                    </div>
                    <p className="text-sm text-muted-foreground mt-2">
                      {diagnosticResults.configComplete === null
                        ? "Verificando..."
                        : diagnosticResults.configComplete
                          ? "Token e Chat ID configurados"
                          : "Token ou Chat ID não configurados"}
                    </p>
                  </CardContent>
                </Card>

                <Card>
                  <CardContent className="pt-6">
                    <div className="flex justify-between items-center">
                      <h4 className="font-medium">Conexão com Internet</h4>
                      {getDiagnosticIcon(diagnosticResults.internetConnection)}
                    </div>
                    <p className="text-sm text-muted-foreground mt-2">
                      {diagnosticResults.internetConnection === null
                        ? "Verificando..."
                        : diagnosticResults.internetConnection
                          ? "Conectado à internet"
                          : "Sem conexão com a internet"}
                    </p>
                  </CardContent>
                </Card>

                <Card>
                  <CardContent className="pt-6">
                    <div className="flex justify-between items-center">
                      <h4 className="font-medium">API do Telegram</h4>
                      {getDiagnosticIcon(diagnosticResults.telegramApi)}
                    </div>
                    <p className="text-sm text-muted-foreground mt-2">
                      {diagnosticResults.telegramApi === null
                        ? "Verificando..."
                        : diagnosticResults.telegramApi
                          ? "API acessível"
                          : "Não foi possível acessar a API"}
                    </p>
                  </CardContent>
                </Card>
              </div>

              <div className="mt-6">
                <h4 className="font-medium mb-3">Solução de Problemas Comuns</h4>

                <div className="space-y-3">
                  <details className="border rounded-md">
                    <summary className="px-4 py-2 cursor-pointer font-medium">
                      O bot não responde às minhas mensagens
                    </summary>
                    <div className="px-4 py-2 text-sm border-t">
                      <p>Verifique se:</p>
                      <ul className="list-disc pl-5 mt-2 space-y-1">
                        <li>Você iniciou uma conversa com o bot enviando /start</li>
                        <li>O bot tem permissões para enviar mensagens</li>
                        <li>O token do bot está correto</li>
                      </ul>
                    </div>
                  </details>

                  <details className="border rounded-md">
                    <summary className="px-4 py-2 cursor-pointer font-medium">
                      Erro "Forbidden: bot was blocked by the user"
                    </summary>
                    <div className="px-4 py-2 text-sm border-t">
                      <p>Este erro ocorre quando:</p>
                      <ul className="list-disc pl-5 mt-2 space-y-1">
                        <li>O usuário bloqueou o bot no Telegram</li>
                        <li>O chat foi deletado</li>
                      </ul>
                      <p className="mt-2">Solução: Desbloqueie o bot e envie /start novamente.</p>
                    </div>
                  </details>

                  <details className="border rounded-md">
                    <summary className="px-4 py-2 cursor-pointer font-medium">
                      Erro "Bad Request: chat not found"
                    </summary>
                    <div className="px-4 py-2 text-sm border-t">
                      <p>Este erro ocorre quando:</p>
                      <ul className="list-disc pl-5 mt-2 space-y-1">
                        <li>O ID do chat está incorreto</li>
                        <li>O bot nunca iniciou uma conversa com este chat</li>
                      </ul>
                      <p className="mt-2">
                        Solução: Verifique o ID do chat e certifique-se de que o bot foi adicionado ao chat.
                      </p>
                    </div>
                  </details>

                  <details className="border rounded-md">
                    <summary className="px-4 py-2 cursor-pointer font-medium">Erro "Unauthorized"</summary>
                    <div className="px-4 py-2 text-sm border-t">
                      <p>Este erro ocorre quando:</p>
                      <ul className="list-disc pl-5 mt-2 space-y-1">
                        <li>O token do bot está incorreto</li>
                        <li>O bot foi revogado pelo BotFather</li>
                      </ul>
                      <p className="mt-2">Solução: Verifique o token do bot ou crie um novo bot no BotFather.</p>
                    </div>
                  </details>
                </div>
              </div>
            </div>
          </TabsContent>
        </Tabs>
      </CardContent>
      <CardFooter className="flex justify-between">
        {activeTab === "testar" && (
          <Button
            onClick={handleSendTest}
            disabled={isTesting || !telegramConfig.botToken || !telegramConfig.chatId}
            className="ml-auto"
          >
            {isTesting ? (
              <>
                <Loader2 className="mr-2 h-4 w-4 animate-spin" />
                Enviando...
              </>
            ) : (
              <>
                <Send className="mr-2 h-4 w-4" />
                Enviar Notificação de Teste
              </>
            )}
          </Button>
        )}
      </CardFooter>
    </Card>
  )
}
