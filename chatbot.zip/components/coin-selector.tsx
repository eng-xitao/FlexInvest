"use client"

import { useState } from "react"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Popover, PopoverContent, PopoverTrigger } from "@/components/ui/popover"
import { ChevronDown, Search, Loader2 } from "lucide-react"

type Coin = {
  id: string
  name: string
  symbol: string
  image?: string
}

interface CoinSelectorProps {
  selectedCoin: string
  onSelectCoin: (coinId: string) => void
  isLoading?: boolean
}

export function CoinSelector({ selectedCoin, onSelectCoin, isLoading = false }: CoinSelectorProps) {
  const [availableCoins, setAvailableCoins] = useState<Coin[]>([
    { id: "bitcoin", name: "Bitcoin (BTC)", symbol: "BTC" },
    { id: "ethereum", name: "Ethereum (ETH)", symbol: "ETH" },
    { id: "tether", name: "Tether (USDT)", symbol: "USDT" },
    { id: "binancecoin", name: "BNB (BNB)", symbol: "BNB" },
    { id: "ripple", name: "XRP (XRP)", symbol: "XRP" },
    { id: "solana", name: "Solana (SOL)", symbol: "SOL" },
    { id: "cardano", name: "Cardano (ADA)", symbol: "ADA" },
    { id: "dogecoin", name: "Dogecoin (DOGE)", symbol: "DOGE" },
    { id: "polkadot", name: "Polkadot (DOT)", symbol: "DOT" },
    { id: "matic-network", name: "Polygon (MATIC)", symbol: "MATIC" },
    { id: "litecoin", name: "Litecoin (LTC)", symbol: "LTC" },
    { id: "shiba-inu", name: "Shiba Inu (SHIB)", symbol: "SHIB" },
    { id: "avalanche-2", name: "Avalanche (AVAX)", symbol: "AVAX" },
    { id: "chainlink", name: "Chainlink (LINK)", symbol: "LINK" },
    { id: "uniswap", name: "Uniswap (UNI)", symbol: "UNI" },
    { id: "stellar", name: "Stellar (XLM)", symbol: "XLM" },
    { id: "cosmos", name: "Cosmos (ATOM)", symbol: "ATOM" },
    { id: "monero", name: "Monero (XMR)", symbol: "XMR" },
    { id: "ethereum-classic", name: "Ethereum Classic (ETC)", symbol: "ETC" },
    { id: "filecoin", name: "Filecoin (FIL)", symbol: "FIL" },
    { id: "hedera-hashgraph", name: "Hedera (HBAR)", symbol: "HBAR" },
    { id: "internet-computer", name: "Internet Computer (ICP)", symbol: "ICP" },
    { id: "near", name: "NEAR Protocol (NEAR)", symbol: "NEAR" },
    { id: "vechain", name: "VeChain (VET)", symbol: "VET" },
    { id: "algorand", name: "Algorand (ALGO)", symbol: "ALGO" },
    { id: "tezos", name: "Tezos (XTZ)", symbol: "XTZ" },
    { id: "the-sandbox", name: "The Sandbox (SAND)", symbol: "SAND" },
    { id: "decentraland", name: "Decentraland (MANA)", symbol: "MANA" },
    { id: "aave", name: "Aave (AAVE)", symbol: "AAVE" },
    { id: "eos", name: "EOS (EOS)", symbol: "EOS" },
    // Top 50 criptomoedas
    { id: "apecoin", name: "ApeCoin (APE)", symbol: "APE" },
    { id: "axie-infinity", name: "Axie Infinity (AXS)", symbol: "AXS" },
    { id: "bitcoin-cash", name: "Bitcoin Cash (BCH)", symbol: "BCH" },
    { id: "compound-governance-token", name: "Compound (COMP)", symbol: "COMP" },
    { id: "dash", name: "Dash (DASH)", symbol: "DASH" },
    { id: "elrond-erd-2", name: "MultiversX (EGLD)", symbol: "EGLD" },
    { id: "flow", name: "Flow (FLOW)", symbol: "FLOW" },
    { id: "ftx-token", name: "FTX Token (FTT)", symbol: "FTT" },
    { id: "gala", name: "Gala (GALA)", symbol: "GALA" },
    { id: "harmony", name: "Harmony (ONE)", symbol: "ONE" },
    { id: "iota", name: "IOTA (MIOTA)", symbol: "MIOTA" },
    { id: "klay-token", name: "Klaytn (KLAY)", symbol: "KLAY" },
    { id: "kusama", name: "Kusama (KSM)", symbol: "KSM" },
    { id: "maker", name: "Maker (MKR)", symbol: "MKR" },
    { id: "neo", name: "NEO (NEO)", symbol: "NEO" },
    { id: "pancakeswap-token", name: "PancakeSwap (CAKE)", symbol: "CAKE" },
    { id: "quant-network", name: "Quant (QNT)", symbol: "QNT" },
    { id: "synthetix-network-token", name: "Synthetix (SNX)", symbol: "SNX" },
    { id: "theta-token", name: "Theta Network (THETA)", symbol: "THETA" },
    { id: "zcash", name: "Zcash (ZEC)", symbol: "ZEC" },
  ])

  const [coinSearch, setCoinSearch] = useState("")
  const [isLoadingCoins, setIsLoadingCoins] = useState(false)
  const [isPopoverOpen, setIsPopoverOpen] = useState(false)

  // Função para buscar lista de criptomoedas da API
  const fetchCoinList = async () => {
    setIsLoadingCoins(true)
    try {
      const response = await fetch(
        "https://api.coingecko.com/api/v3/coins/markets?vs_currency=usd&order=market_cap_desc&per_page=100&page=1",
      )

      if (response.ok) {
        const data = await response.json()
        const formattedCoins = data.map((coin) => ({
          id: coin.id,
          name: `${coin.name} (${coin.symbol.toUpperCase()})`,
          symbol: coin.symbol.toUpperCase(),
          image: coin.image,
        }))
        setAvailableCoins(formattedCoins)
      }
    } catch (error) {
      console.error("Erro ao buscar lista de criptomoedas:", error)
      // Manter a lista estática em caso de erro
    } finally {
      setIsLoadingCoins(false)
    }
  }

  // Buscar lista de criptomoedas ao abrir o popover pela primeira vez
  const handlePopoverOpen = (open: boolean) => {
    setIsPopoverOpen(open)
    if (open && availableCoins.length <= 50 && !isLoadingCoins) {
      // Comentado para evitar atingir limites de API durante o desenvolvimento
      // fetchCoinList()
    }
  }

  // Filtrar criptomoedas com base na busca
  const filteredCoins = coinSearch
    ? availableCoins.filter(
        (coin) =>
          coin.name.toLowerCase().includes(coinSearch.toLowerCase()) ||
          coin.symbol.toLowerCase().includes(coinSearch.toLowerCase()),
      )
    : availableCoins

  // Ordenar por símbolo para facilitar a busca
  const sortedCoins = [...filteredCoins].sort((a, b) => a.symbol.localeCompare(b.symbol))

  return (
    <Popover open={isPopoverOpen} onOpenChange={handlePopoverOpen}>
      <PopoverTrigger asChild>
        <Button variant="outline" className="w-[220px] justify-between">
          {isLoading ? (
            <span className="flex items-center">
              <Loader2 className="mr-2 h-4 w-4 animate-spin" />
              Carregando...
            </span>
          ) : (
            <span className="truncate">
              {availableCoins.find((c) => c.id === selectedCoin)?.name || "Selecione uma moeda"}
            </span>
          )}
          <ChevronDown className="ml-2 h-4 w-4 shrink-0 opacity-50" />
        </Button>
      </PopoverTrigger>
      <PopoverContent className="w-[280px] p-0" align="start">
        <div className="p-2">
          <div className="flex items-center border rounded-md">
            <Search className="ml-2 h-4 w-4 shrink-0 opacity-50" />
            <Input
              placeholder="Buscar criptomoeda..."
              value={coinSearch}
              onChange={(e) => setCoinSearch(e.target.value)}
              className="border-0 focus-visible:ring-0 focus-visible:ring-offset-0"
            />
            {coinSearch && (
              <Button variant="ghost" onClick={() => setCoinSearch("")} className="h-8 w-8 p-0 mr-1">
                &times;
              </Button>
            )}
          </div>
        </div>
        <div className="max-h-[300px] overflow-auto">
          {isLoadingCoins ? (
            <div className="flex justify-center items-center py-4">
              <Loader2 className="mr-2 h-4 w-4 animate-spin" />
              Carregando moedas...
            </div>
          ) : sortedCoins.length > 0 ? (
            sortedCoins.map((coin) => (
              <div
                key={coin.id}
                className={`flex items-center px-3 py-2 cursor-pointer hover:bg-muted ${
                  selectedCoin === coin.id ? "bg-muted" : ""
                }`}
                onClick={() => {
                  onSelectCoin(coin.id)
                  setCoinSearch("")
                  setIsPopoverOpen(false)
                }}
              >
                {coin.image && (
                  <img
                    src={coin.image || "/placeholder.svg"}
                    alt={coin.symbol}
                    className="w-5 h-5 mr-2"
                    onError={(e) => {
                      // Remover src em caso de erro para não mostrar ícone quebrado
                      e.currentTarget.src = ""
                      e.currentTarget.style.display = "none"
                    }}
                  />
                )}
                <div className="font-medium">{coin.symbol}</div>
                <div className="ml-2 text-sm text-muted-foreground truncate">{coin.name.split("(")[0].trim()}</div>
              </div>
            ))
          ) : (
            <div className="text-center py-4 text-muted-foreground">Nenhuma moeda encontrada</div>
          )}
        </div>
      </PopoverContent>
    </Popover>
  )
}
