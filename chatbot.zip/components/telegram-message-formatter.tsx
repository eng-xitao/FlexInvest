"use client"

import { useState } from "react"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"

interface TelegramMessageProps {
  type: "buy" | "sell" | "menu" | "flash" | "confirmation" | "error"
  data: any
  onCopy?: () => void
}

export function TelegramMessageFormatter({ type, data, onCopy }: TelegramMessageProps) {
  const [activeTab, setActiveTab] = useState<"preview" | "code">("preview")

  const formatMessage = () => {
    switch (type) {
      case "buy":
        return formatBuySignal(data)
      case "sell":
        return formatSellSignal(data)
      case "menu":
        return formatMenu(data)
      case "flash":
        return formatFlashSignal(data)
      case "confirmation":
        return formatConfirmation(data)
      case "error":
        return formatError(data)
      default:
        return "Tipo de mensagem não suportado"
    }
  }

  const formatBuySignal = (data: any) => {
    return `🚨 Alerta de Trading - FlexInvest

📊 Moeda: ${data.symbol}
💲 Preço Atual: R$${data.price.toFixed(2)}
📈 Ação: COMPRA
📊 Variação 1h: ${data.variation1h > 0 ? "+" : ""}${data.variation1h.toFixed(2)}%
✅ Confiabilidade: ${data.confidence}%

🕒 Horário de Entrada: ${data.entryTime}
⏳ Expiração: Entrada válida por ${data.expirationMinutes} minutos

📝 Justificativa: ${data.justification}

🤖 Sinal gerado automaticamente por FlexInvest`
  }

  const formatSellSignal = (data: any) => {
    return `🚨 Alerta de Trading - FlexInvest

📊 Moeda: ${data.symbol}
💲 Preço Atual: R$${data.price.toFixed(2)}
📉 Ação: VENDA
📊 Variação 1h: ${data.variation1h > 0 ? "+" : ""}${data.variation1h.toFixed(2)}%
✅ Confiabilidade: ${data.confidence}%

🕒 Horário de Entrada: ${data.entryTime}
⏳ Expiração: Entrada válida por ${data.expirationMinutes} minutos

📝 Justificativa: ${data.justification}

🤖 Sinal gerado automaticamente por FlexInvest`
  }

  const formatMenu = (data: any) => {
    return `🤖 FlexInvest Trading Bot - Menu Principal 🤖

${data.notificationsEnabled ? "🔔 Notificações: ON" : "🔕 Notificações: OFF"}

📊 Ver Sinais Ativos
⚙️ Configurações
📈 Escolher Moedas
ℹ️ Status do Sistema
❓ Ajuda`
  }

  const formatFlashSignal = (data: any) => {
    return `📢 Flash: ${data.symbol}
⏳ Expiração: ${data.expirationMinutes} minutos
${data.action === "buy" ? "🟢 COMPRA" : "🔴 VENDA"}
🕒 Entrada: ${data.entryTime}

Gale 1 - ${data.gale1Time}
Gale 2 - ${data.gale2Time}

👉 Até gale ${data.maxGale} se necessário

🔗 Clique aqui para abrir a corretora`
  }

  const formatConfirmation = (data: any) => {
    return `✅ Operação Confirmada

📊 ${data.symbol} - ${data.action === "buy" ? "COMPRA" : "VENDA"}
💰 Preço: R$${data.price.toFixed(2)}
🕒 Horário: ${data.time}
${data.profit ? `💵 Lucro: ${data.profit > 0 ? "+" : ""}${data.profit.toFixed(2)}%` : ""}

${data.message}`
  }

  const formatError = (data: any) => {
    return `❌ Operação Não Realizada

📊 ${data.symbol} - ${data.action === "buy" ? "COMPRA" : "VENDA"}
⚠️ Motivo: ${data.reason}

${data.message}`
  }

  const handleCopy = () => {
    navigator.clipboard.writeText(formatMessage())
    if (onCopy) onCopy()
  }

  return (
    <Card className="w-full">
      <CardHeader className="pb-2">
        <CardTitle className="text-lg flex items-center justify-between">
          <span>Mensagem para Telegram</span>
          <Tabs value={activeTab} onValueChange={(value) => setActiveTab(value as "preview" | "code")}>
            <TabsList className="grid w-[180px] grid-cols-2">
              <TabsTrigger value="preview">Visualização</TabsTrigger>
              <TabsTrigger value="code">Código</TabsTrigger>
            </TabsList>
          </Tabs>
        </CardTitle>
      </CardHeader>
      <CardContent>
        <TabsContent value="preview" className="mt-0">
          <div className="bg-[#f5f5f5] dark:bg-[#1e1e1e] rounded-md p-4 font-mono text-sm whitespace-pre-wrap">
            {formatMessage()}
          </div>
        </TabsContent>
        <TabsContent value="code" className="mt-0">
          <div className="bg-[#f5f5f5] dark:bg-[#1e1e1e] rounded-md p-4 font-mono text-sm overflow-x-auto">
            <pre>{`\`\`\`\n${formatMessage()}\n\`\`\``}</pre>
          </div>
        </TabsContent>
        <div className="mt-4 flex justify-end">
          <Button onClick={handleCopy}>Copiar Mensagem</Button>
        </div>
      </CardContent>
    </Card>
  )
}
