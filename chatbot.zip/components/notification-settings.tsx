"use client"

import { useState } from "react"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Switch } from "@/components/ui/switch"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { BellRing, Send, MessageSquare, Mail } from "lucide-react"
import { sendTelegramNotification } from "@/lib/notification-service"
import { useToast } from "@/hooks/use-toast"

interface NotificationSettingsProps {
  notificationConfig: any
  onUpdateConfig: (config: any) => void
}

export function NotificationSettings({ notificationConfig, onUpdateConfig }: NotificationSettingsProps) {
  const [telegramConfig, setTelegramConfig] = useState({
    botToken: notificationConfig.telegram?.botToken || "",
    chatId: notificationConfig.telegram?.chatId || "",
  })
  const [isTesting, setIsTesting] = useState(false)
  const { toast } = useToast()

  const handleToggleChannel = (channel: string, enabled: boolean) => {
    const updatedChannels = enabled
      ? [...notificationConfig.channels, channel]
      : notificationConfig.channels.filter((c) => c !== channel)

    onUpdateConfig({
      ...notificationConfig,
      channels: updatedChannels,
    })
  }

  const handleToggleNotifications = (enabled: boolean) => {
    onUpdateConfig({
      ...notificationConfig,
      enabled,
    })
  }

  const updateTelegramConfig = () => {
    onUpdateConfig({
      ...notificationConfig,
      telegram: telegramConfig,
    })

    toast({
      title: "Configurações salvas",
      description: "As configurações do Telegram foram atualizadas",
    })
  }

  const testTelegramNotification = async () => {
    setIsTesting(true)
    try {
      const success = await sendTelegramNotification(
        telegramConfig.botToken,
        telegramConfig.chatId,
        "🤖 <b>Teste de Notificação</b>\n\nSeu robô de trading está configurado corretamente para enviar alertas via Telegram.",
      )

      if (success) {
        toast({
          title: "Teste enviado com sucesso",
          description: "Verifique seu Telegram para confirmar o recebimento",
        })
      } else {
        toast({
          title: "Falha no envio",
          description: "Não foi possível enviar a mensagem de teste. Verifique as configurações.",
          variant: "destructive",
        })
      }
    } catch (error) {
      toast({
        title: "Erro",
        description: "Ocorreu um erro ao testar a notificação",
        variant: "destructive",
      })
    } finally {
      setIsTesting(false)
    }
  }

  return (
    <Card>
      <CardHeader>
        <CardTitle>Configurações de Notificação</CardTitle>
        <CardDescription>Configure como deseja receber alertas e sinais de trading</CardDescription>
      </CardHeader>
      <CardContent className="space-y-6">
        <div className="flex items-center justify-between">
          <div className="flex items-center space-x-2">
            <BellRing className="h-5 w-5" />
            <Label htmlFor="notifications-enabled" className="font-medium">
              Notificações
            </Label>
          </div>
          <Switch
            id="notifications-enabled"
            checked={notificationConfig.enabled}
            onCheckedChange={handleToggleNotifications}
          />
        </div>

        <Tabs defaultValue="telegram" className="w-full">
          <TabsList className="grid w-full grid-cols-3">
            <TabsTrigger value="telegram" className="flex items-center">
              <Send className="h-4 w-4 mr-2" />
              Telegram
            </TabsTrigger>
            <TabsTrigger value="whatsapp" className="flex items-center" disabled>
              <MessageSquare className="h-4 w-4 mr-2" />
              WhatsApp
            </TabsTrigger>
            <TabsTrigger value="email" className="flex items-center" disabled>
              <Mail className="h-4 w-4 mr-2" />
              Email
            </TabsTrigger>
          </TabsList>

          <TabsContent value="telegram" className="space-y-4 mt-4">
            <div className="flex items-center justify-between">
              <Label htmlFor="telegram-enabled" className="flex items-center space-x-2">
                <Send className="h-4 w-4" />
                <span>Ativar notificações via Telegram</span>
              </Label>
              <Switch
                id="telegram-enabled"
                checked={notificationConfig.channels.includes("telegram")}
                onCheckedChange={(checked) => handleToggleChannel("telegram", checked)}
              />
            </div>

            <div className="space-y-4 mt-4">
              <div className="space-y-2">
                <Label htmlFor="bot-token">Token do Bot</Label>
                <Input
                  id="bot-token"
                  type="password"
                  placeholder="1234567890:ABCDEFGHIJKLMNOPQRSTUVWXYZ"
                  value={telegramConfig.botToken}
                  onChange={(e) => setTelegramConfig({ ...telegramConfig, botToken: e.target.value })}
                />
                <p className="text-xs text-muted-foreground">
                  Obtenha um token criando um bot com @BotFather no Telegram
                </p>
              </div>

              <div className="space-y-2">
                <Label htmlFor="chat-id">ID do Chat</Label>
                <Input
                  id="chat-id"
                  placeholder="123456789"
                  value={telegramConfig.chatId}
                  onChange={(e) => setTelegramConfig({ ...telegramConfig, chatId: e.target.value })}
                />
                <p className="text-xs text-muted-foreground">
                  Envie uma mensagem para @userinfobot para obter seu Chat ID
                </p>
              </div>

              <div className="flex space-x-2 pt-2">
                <Button onClick={updateTelegramConfig} className="flex-1">
                  Salvar Configurações
                </Button>
                <Button
                  variant="outline"
                  onClick={testTelegramNotification}
                  disabled={isTesting || !telegramConfig.botToken || !telegramConfig.chatId}
                  className="flex-1"
                >
                  {isTesting ? "Enviando..." : "Testar Notificação"}
                </Button>
              </div>
            </div>
          </TabsContent>

          <TabsContent value="whatsapp" className="space-y-4 mt-4">
            <div className="flex flex-col items-center justify-center py-8 text-center">
              <MessageSquare className="h-10 w-10 text-muted-foreground mb-4" />
              <h3 className="text-lg font-medium mb-2">Em breve</h3>
              <p className="text-muted-foreground max-w-md">
                A integração com WhatsApp estará disponível em uma atualização futura.
              </p>
            </div>
          </TabsContent>

          <TabsContent value="email" className="space-y-4 mt-4">
            <div className="flex flex-col items-center justify-center py-8 text-center">
              <Mail className="h-10 w-10 text-muted-foreground mb-4" />
              <h3 className="text-lg font-medium mb-2">Em breve</h3>
              <p className="text-muted-foreground max-w-md">
                A integração com Email estará disponível em uma atualização futura.
              </p>
            </div>
          </TabsContent>
        </Tabs>

        <div className="space-y-4 pt-4">
          <h3 className="font-medium">Tipos de Notificação</h3>
          <div className="space-y-2">
            <div className="flex items-center justify-between">
              <Label htmlFor="notify-alerts" className="flex items-center space-x-2">
                <span>Alertas de preço e indicadores</span>
              </Label>
              <Switch id="notify-alerts" defaultChecked />
            </div>
            <div className="flex items-center justify-between">
              <Label htmlFor="notify-signals" className="flex items-center space-x-2">
                <span>Sinais de trading</span>
              </Label>
              <Switch id="notify-signals" defaultChecked />
            </div>
            <div className="flex items-center justify-between">
              <Label htmlFor="notify-orders" className="flex items-center space-x-2">
                <span>Execução de ordens</span>
              </Label>
              <Switch id="notify-orders" defaultChecked />
            </div>
          </div>
        </div>
      </CardContent>
    </Card>
  )
}
