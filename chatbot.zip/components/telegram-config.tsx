"use client"

import { useState, useEffect } from "react"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Switch } from "@/components/ui/switch"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import { Loader2, Send, MessageSquare, CheckCircle2, Info } from "lucide-react"
import { useToast } from "@/components/ui/use-toast"
import Link from "next/link"
import { sendTelegramNotification, testTelegramConnection, verifyChatId } from "@/lib/notification-service"
import { saveConfig, getConfig } from "@/lib/config-service"

export function TelegramConfig() {
  const { toast } = useToast()
  const [isTesting, setIsTesting] = useState(false)
  const [isSaving, setIsSaving] = useState(false)
  const [isLoading, setIsLoading] = useState(true)

  const [telegramConfig, setTelegramConfig] = useState({
    enabled: false,
    botToken: "",
    chatId: "",
    autoNotify: {
      signals: true,
      alerts: true,
      dailySummary: true,
      marketUpdates: false,
      errorNotifications: true,
    },
    notificationSchedule: {
      frequency: "realtime",
      customMinutes: 30,
      quietHoursStart: "22:00",
      quietHoursEnd: "08:00",
      enableQuietHours: false,
    },
  })

  // Carregar configurações ao iniciar
  useEffect(() => {
    async function loadConfig() {
      try {
        const config = await getConfig("telegram")
        if (config) {
          setTelegramConfig(config)
        }
      } catch (error) {
        console.error("Erro ao carregar configurações:", error)
        toast({
          title: "Erro",
          description: "Não foi possível carregar as configurações do Telegram",
          variant: "destructive",
        })
      } finally {
        setIsLoading(false)
      }
    }

    loadConfig()
  }, [toast])

  const handleConfigChange = (path, value) => {
    const newConfig = { ...telegramConfig }
    let current = newConfig

    if (typeof path === "string") {
      path = [path]
    }

    for (let i = 0; i < path.length - 1; i++) {
      current = current[path[i]]
    }

    current[path[path.length - 1]] = value
    setTelegramConfig(newConfig)
  }

  const testTelegramNotification = async () => {
    if (!telegramConfig.botToken || !telegramConfig.chatId) {
      toast({
        title: "Configuração incompleta",
        description: "Por favor, preencha o Token do Bot e o ID do Chat antes de testar.",
        variant: "destructive",
      })
      return
    }

    setIsTesting(true)

    try {
      // Primeiro, testa a conexão com a API do Telegram
      const connectionTest = await testTelegramConnection(telegramConfig.botToken)

      if (!connectionTest.success) {
        toast({
          title: "Erro de conexão",
          description: connectionTest.error || "Não foi possível conectar à API do Telegram",
          variant: "destructive",
        })
        return
      }

      // Em seguida, verifica se o chat ID é válido
      const chatTest = await verifyChatId(telegramConfig.botToken, telegramConfig.chatId)

      if (!chatTest.success) {
        toast({
          title: "Chat ID inválido",
          description: chatTest.error || "O ID do chat fornecido não é válido ou o bot não tem acesso a ele",
          variant: "destructive",
        })
        return
      }

      // Por fim, envia uma mensagem de teste
      const result = await sendTelegramNotification(
        telegramConfig.botToken,
        telegramConfig.chatId,
        `🤖 <b>Teste de Notificação</b>\n\nSeu robô de trading FlexInvest está configurado corretamente para enviar alertas via Telegram.\n\nData e hora: ${new Date().toLocaleString()}`,
      )

      if (result.success) {
        toast({
          title: "Teste enviado com sucesso",
          description: "Verifique seu Telegram para confirmar o recebimento da mensagem",
        })
      } else {
        toast({
          title: "Falha no envio",
          description: result.error || "Não foi possível enviar a mensagem de teste",
          variant: "destructive",
        })
      }
    } catch (error) {
      toast({
        title: "Erro",
        description: "Ocorreu um erro ao testar a notificação",
        variant: "destructive",
      })
    } finally {
      setIsTesting(false)
    }
  }

  const saveSettings = async () => {
    setIsSaving(true)

    try {
      const result = await saveConfig("telegram", telegramConfig)

      if (result.success) {
        toast({
          title: "Configurações salvas",
          description: "As configurações do Telegram foram atualizadas com sucesso",
        })
      } else {
        toast({
          title: "Erro ao salvar",
          description: "Não foi possível salvar as configurações",
          variant: "destructive",
        })
      }
    } catch (error) {
      toast({
        title: "Erro",
        description: "Ocorreu um erro ao salvar as configurações",
        variant: "destructive",
      })
    } finally {
      setIsSaving(false)
    }
  }

  if (isLoading) {
    return (
      <div className="flex justify-center items-center p-8">
        <Loader2 className="h-8 w-8 animate-spin text-muted-foreground" />
      </div>
    )
  }

  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between">
        <div>
          <h3 className="text-lg font-medium">Configurações do Telegram</h3>
          <p className="text-sm text-muted-foreground">Configure seu bot do Telegram para receber alertas e sinais</p>
        </div>
        <div className="flex items-center space-x-2">
          <Label htmlFor="telegram-enabled">Ativar Telegram</Label>
          <Switch
            id="telegram-enabled"
            checked={telegramConfig.enabled}
            onCheckedChange={(checked) => handleConfigChange("enabled", checked)}
          />
        </div>
      </div>

      <div className="space-y-4">
        <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
          <div className="space-y-2">
            <Label htmlFor="bot-token">Token do Bot</Label>
            <Input
              id="bot-token"
              type="password"
              placeholder="1234567890:ABCDEFGHIJKLMNOPQRSTUVWXYZ"
              value={telegramConfig.botToken}
              onChange={(e) => handleConfigChange("botToken", e.target.value)}
            />
            <p className="text-xs text-muted-foreground">Obtenha um token criando um bot com @BotFather no Telegram</p>
          </div>

          <div className="space-y-2">
            <Label htmlFor="chat-id">ID do Chat</Label>
            <Input
              id="chat-id"
              placeholder="123456789"
              value={telegramConfig.chatId}
              onChange={(e) => handleConfigChange("chatId", e.target.value)}
            />
            <p className="text-xs text-muted-foreground">Envie uma mensagem para @userinfobot para obter seu Chat ID</p>
          </div>
        </div>

        <Tabs defaultValue="notifications" className="w-full">
          <TabsList className="grid w-full grid-cols-2">
            <TabsTrigger value="notifications">Notificações Automáticas</TabsTrigger>
            <TabsTrigger value="schedule">Programação</TabsTrigger>
          </TabsList>

          <TabsContent value="notifications" className="space-y-4 mt-4">
            <div className="space-y-4">
              <h3 className="font-medium">Tipos de Notificação Automática</h3>
              <div className="space-y-2">
                <div className="flex items-center justify-between">
                  <Label htmlFor="notify-signals" className="flex items-center space-x-2">
                    <span>Sinais de trading</span>
                  </Label>
                  <Switch
                    id="notify-signals"
                    checked={telegramConfig.autoNotify.signals}
                    onCheckedChange={(checked) => handleConfigChange(["autoNotify", "signals"], checked)}
                  />
                </div>
                <div className="flex items-center justify-between">
                  <Label htmlFor="notify-alerts" className="flex items-center space-x-2">
                    <span>Alertas de preço e indicadores</span>
                  </Label>
                  <Switch
                    id="notify-alerts"
                    checked={telegramConfig.autoNotify.alerts}
                    onCheckedChange={(checked) => handleConfigChange(["autoNotify", "alerts"], checked)}
                  />
                </div>
                <div className="flex items-center justify-between">
                  <Label htmlFor="notify-summary" className="flex items-center space-x-2">
                    <span>Resumo diário</span>
                  </Label>
                  <Switch
                    id="notify-summary"
                    checked={telegramConfig.autoNotify.dailySummary}
                    onCheckedChange={(checked) => handleConfigChange(["autoNotify", "dailySummary"], checked)}
                  />
                </div>
                <div className="flex items-center justify-between">
                  <Label htmlFor="notify-market" className="flex items-center space-x-2">
                    <span>Atualizações de mercado</span>
                  </Label>
                  <Switch
                    id="notify-market"
                    checked={telegramConfig.autoNotify.marketUpdates}
                    onCheckedChange={(checked) => handleConfigChange(["autoNotify", "marketUpdates"], checked)}
                  />
                </div>
                <div className="flex items-center justify-between">
                  <Label htmlFor="notify-errors" className="flex items-center space-x-2">
                    <span>Notificações de erro</span>
                  </Label>
                  <Switch
                    id="notify-errors"
                    checked={telegramConfig.autoNotify.errorNotifications}
                    onCheckedChange={(checked) => handleConfigChange(["autoNotify", "errorNotifications"], checked)}
                  />
                </div>
              </div>
            </div>
          </TabsContent>

          <TabsContent value="schedule" className="space-y-4 mt-4">
            <div className="space-y-4">
              <div className="space-y-2">
                <Label htmlFor="frequency">Frequência de Notificações</Label>
                <Select
                  value={telegramConfig.notificationSchedule.frequency}
                  onValueChange={(value) => handleConfigChange(["notificationSchedule", "frequency"], value)}
                >
                  <SelectTrigger id="frequency">
                    <SelectValue placeholder="Selecione a frequência" />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="realtime">Tempo real</SelectItem>
                    <SelectItem value="hourly">A cada hora</SelectItem>
                    <SelectItem value="daily">Diariamente</SelectItem>
                    <SelectItem value="custom">Personalizado</SelectItem>
                  </SelectContent>
                </Select>
              </div>

              {telegramConfig.notificationSchedule.frequency === "custom" && (
                <div className="space-y-2">
                  <Label htmlFor="custom-minutes">Intervalo (minutos)</Label>
                  <Input
                    id="custom-minutes"
                    type="number"
                    min="1"
                    max="1440"
                    value={telegramConfig.notificationSchedule.customMinutes}
                    onChange={(e) =>
                      handleConfigChange(["notificationSchedule", "customMinutes"], Number.parseInt(e.target.value))
                    }
                  />
                </div>
              )}

              <div className="space-y-2 pt-2">
                <div className="flex items-center justify-between">
                  <Label htmlFor="quiet-hours" className="flex items-center space-x-2">
                    <span>Ativar Horário Silencioso</span>
                  </Label>
                  <Switch
                    id="quiet-hours"
                    checked={telegramConfig.notificationSchedule.enableQuietHours}
                    onCheckedChange={(checked) =>
                      handleConfigChange(["notificationSchedule", "enableQuietHours"], checked)
                    }
                  />
                </div>

                {telegramConfig.notificationSchedule.enableQuietHours && (
                  <div className="grid grid-cols-2 gap-4 mt-2">
                    <div className="space-y-2">
                      <Label htmlFor="quiet-start">Início</Label>
                      <Input
                        id="quiet-start"
                        type="time"
                        value={telegramConfig.notificationSchedule.quietHoursStart}
                        onChange={(e) =>
                          handleConfigChange(["notificationSchedule", "quietHoursStart"], e.target.value)
                        }
                      />
                    </div>
                    <div className="space-y-2">
                      <Label htmlFor="quiet-end">Fim</Label>
                      <Input
                        id="quiet-end"
                        type="time"
                        value={telegramConfig.notificationSchedule.quietHoursEnd}
                        onChange={(e) => handleConfigChange(["notificationSchedule", "quietHoursEnd"], e.target.value)}
                      />
                    </div>
                  </div>
                )}
              </div>
            </div>
          </TabsContent>
        </Tabs>

        <div className="flex flex-col sm:flex-row gap-2 pt-4">
          <Button
            onClick={testTelegramNotification}
            variant="outline"
            disabled={isTesting || !telegramConfig.botToken || !telegramConfig.chatId}
            className="flex-1"
          >
            {isTesting ? (
              <>
                <Loader2 className="mr-2 h-4 w-4 animate-spin" />
                Testando...
              </>
            ) : (
              <>
                <Send className="mr-2 h-4 w-4" />
                Testar Notificação
              </>
            )}
          </Button>
          <Button onClick={saveSettings} disabled={isSaving} className="flex-1">
            {isSaving ? (
              <>
                <Loader2 className="mr-2 h-4 w-4 animate-spin" />
                Salvando...
              </>
            ) : (
              <>
                <CheckCircle2 className="mr-2 h-4 w-4" />
                Salvar Configurações
              </>
            )}
          </Button>
        </div>

        <div className="flex justify-between items-center pt-4 border-t">
          <div className="flex items-center space-x-2">
            <Info className="h-4 w-4 text-muted-foreground" />
            <p className="text-sm text-muted-foreground">Personalize o formato das mensagens</p>
          </div>
          <Button variant="outline" asChild size="sm">
            <Link href="/telegram-messages">
              <MessageSquare className="h-4 w-4 mr-2" />
              Formatos de Mensagem
            </Link>
          </Button>
        </div>
      </div>
    </div>
  )
}
