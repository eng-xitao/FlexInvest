"use client"

interface OrderBookProps {
  symbol: string
  depth?: number
  exchangeName?: string
  autoRefresh?: boolean
  refreshInterval?: number
}

export function OrderBook({
  symbol,
  depth = 10,
  exchangeName,
  autoRefresh = true,
  refreshInterval = 5000
}: OrderBook\
