"use client"

import { useState, useEffect } from "react"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { Switch } from "@/components/ui/switch"
import { Badge } from "@/components/ui/badge"
import { Check, X, AlertTriangle, RefreshCw } from "lucide-react"
import { useToast } from "@/hooks/use-toast"
import { type ApiConfig, type ExchangeType, exchangeManager, createExchange } from "@/lib/exchange-service"

interface ExchangeSettingsProps {
  onConfigChange?: (configs: Record<string, ApiConfig>) => void
}

export function ExchangeSettings({ onConfigChange }: ExchangeSettingsProps) {
  const { toast } = useToast()
  const [activeTab, setActiveTab] = useState<ExchangeType>("binance")
  const [isTestingConnection, setIsTestingConnection] = useState<Record<string, boolean>>({})
  const [connectionStatus, setConnectionStatus] = useState<Record<string, boolean | null>>({})

  // Estado para armazenar as configurações de cada exchange
  const [configs, setConfigs] = useState<Record<string, ApiConfig>>({
    binance: {
      exchange: "binance",
      apiKey: "",
      apiSecret: "",
      testnet: false,
    },
    coinbase: {
      exchange: "coinbase",
      apiKey: "",
      apiSecret: "",
      testnet: false,
    },
    kraken: {
      exchange: "kraken",
      apiKey: "",
      apiSecret: "",
      testnet: false,
    },
  })

  // Carregar configurações salvas ao iniciar
  useEffect(() => {
    const savedConfigs = localStorage.getItem("exchangeConfigs")
    if (savedConfigs) {
      try {
        const parsedConfigs = JSON.parse(savedConfigs)
        setConfigs(parsedConfigs)

        // Configurar exchanges já salvas
        Object.entries(parsedConfigs).forEach(([name, config]) => {
          if (config.apiKey && config.apiSecret) {
            try {
              exchangeManager.addExchange(name, config as ApiConfig)
            } catch (error) {
              console.error(`Erro ao configurar exchange ${name}:`, error)
            }
          }
        })

        // Notificar componente pai
        if (onConfigChange) {
          onConfigChange(parsedConfigs)
        }
      } catch (error) {
        console.error("Erro ao carregar configurações de exchanges:", error)
      }
    }
  }, [onConfigChange])

  // Atualizar configuração de uma exchange
  const updateConfig = (exchange: ExchangeType, field: keyof ApiConfig, value: any) => {
    const newConfigs = {
      ...configs,
      [exchange]: {
        ...configs[exchange],
        [field]: value,
      },
    }

    setConfigs(newConfigs)

    // Salvar no localStorage
    localStorage.setItem("exchangeConfigs", JSON.stringify(newConfigs))

    // Notificar componente pai
    if (onConfigChange) {
      onConfigChange(newConfigs)
    }
  }

  // Testar conexão com uma exchange
  const testConnection = async (exchange: ExchangeType) => {
    setIsTestingConnection({ ...isTestingConnection, [exchange]: true })
    setConnectionStatus({ ...connectionStatus, [exchange]: null })

    try {
      const config = configs[exchange]

      if (!config.apiKey || !config.apiSecret) {
        toast({
          title: "Configuração incompleta",
          description: "Por favor, preencha a chave de API e a chave secreta.",
          variant: "destructive",
        })
        setConnectionStatus({ ...connectionStatus, [exchange]: false })
        return
      }

      const exchangeInstance = createExchange(config)
      const success = await exchangeInstance.testConnection()

      setConnectionStatus({ ...connectionStatus, [exchange]: success })

      if (success) {
        toast({
          title: "Conexão bem-sucedida",
          description: `Conexão com ${exchange} estabelecida com sucesso.`,
        })

        // Adicionar ao gerenciador de exchanges
        exchangeManager.addExchange(exchange, config)
      } else {
        toast({
          title: "Falha na conexão",
          description: `Não foi possível conectar com ${exchange}. Verifique suas credenciais.`,
          variant: "destructive",
        })
      }
    } catch (error) {
      console.error(`Erro ao testar conexão com ${exchange}:`, error)
      setConnectionStatus({ ...connectionStatus, [exchange]: false })

      toast({
        title: "Erro de conexão",
        description: `Erro ao conectar com ${exchange}: ${error instanceof Error ? error.message : "Erro desconhecido"}`,
        variant: "destructive",
      })
    } finally {
      setIsTestingConnection({ ...isTestingConnection, [exchange]: false })
    }
  }

  // Salvar configuração atual
  const saveConfig = (exchange: ExchangeType) => {
    const config = configs[exchange]

    if (!config.apiKey || !config.apiSecret) {
      toast({
        title: "Configuração incompleta",
        description: "Por favor, preencha a chave de API e a chave secreta.",
        variant: "destructive",
      })
      return
    }

    try {
      // Adicionar ao gerenciador de exchanges
      exchangeManager.addExchange(exchange, config)

      toast({
        title: "Configuração salva",
        description: `Configuração de ${exchange} salva com sucesso.`,
      })
    } catch (error) {
      console.error(`Erro ao salvar configuração de ${exchange}:`, error)

      toast({
        title: "Erro ao salvar",
        description: `Erro ao salvar configuração de ${exchange}: ${error instanceof Error ? error.message : "Erro desconhecido"}`,
        variant: "destructive",
      })
    }
  }

  // Limpar configuração
  const clearConfig = (exchange: ExchangeType) => {
    const newConfigs = {
      ...configs,
      [exchange]: {
        exchange,
        apiKey: "",
        apiSecret: "",
        testnet: false,
      },
    }

    setConfigs(newConfigs)
    setConnectionStatus({ ...connectionStatus, [exchange]: null })

    // Remover do gerenciador de exchanges
    if (exchangeManager.hasExchange(exchange)) {
      exchangeManager.removeExchange(exchange)
    }

    // Salvar no localStorage
    localStorage.setItem("exchangeConfigs", JSON.stringify(newConfigs))

    // Notificar componente pai
    if (onConfigChange) {
      onConfigChange(newConfigs)
    }

    toast({
      title: "Configuração removida",
      description: `Configuração de ${exchange} removida com sucesso.`,
    })
  }

  return (
    <Card>
      <CardHeader>
        <CardTitle>Configurações de Exchanges</CardTitle>
        <CardDescription>Configure suas chaves de API para conectar com exchanges de criptomoedas</CardDescription>
      </CardHeader>
      <CardContent>
        <Tabs value={activeTab} onValueChange={(value) => setActiveTab(value as ExchangeType)}>
          <TabsList className="grid w-full grid-cols-3">
            <TabsTrigger value="binance">
              Binance
              {connectionStatus.binance !== null && (
                <Badge className={`ml-2 ${connectionStatus.binance ? "bg-green-500" : "bg-red-500"}`}>
                  {connectionStatus.binance ? "Conectado" : "Desconectado"}
                </Badge>
              )}
            </TabsTrigger>
            <TabsTrigger value="coinbase">
              Coinbase
              {connectionStatus.coinbase !== null && (
                <Badge className={`ml-2 ${connectionStatus.coinbase ? "bg-green-500" : "bg-red-500"}`}>
                  {connectionStatus.coinbase ? "Conectado" : "Desconectado"}
                </Badge>
              )}
            </TabsTrigger>
            <TabsTrigger value="kraken">
              Kraken
              {connectionStatus.kraken !== null && (
                <Badge className={`ml-2 ${connectionStatus.kraken ? "bg-green-500" : "bg-red-500"}`}>
                  {connectionStatus.kraken ? "Conectado" : "Desconectado"}
                </Badge>
              )}
            </TabsTrigger>
          </TabsList>

          {(["binance", "coinbase", "kraken"] as ExchangeType[]).map((exchange) => (
            <TabsContent key={exchange} value={exchange} className="space-y-4">
              <div className="grid grid-cols-1 gap-4">
                <div className="space-y-2">
                  <Label htmlFor={`${exchange}-api-key`}>Chave de API</Label>
                  <Input
                    id={`${exchange}-api-key`}
                    type="password"
                    value={configs[exchange].apiKey}
                    onChange={(e) => updateConfig(exchange, "apiKey", e.target.value)}
                    placeholder="Insira sua chave de API"
                  />
                  <p className="text-xs text-muted-foreground">
                    A chave de API é fornecida pela exchange e permite acesso à sua conta.
                  </p>
                </div>

                <div className="space-y-2">
                  <Label htmlFor={`${exchange}-api-secret`}>Chave Secreta</Label>
                  <Input
                    id={`${exchange}-api-secret`}
                    type="password"
                    value={configs[exchange].apiSecret}
                    onChange={(e) => updateConfig(exchange, "apiSecret", e.target.value)}
                    placeholder="Insira sua chave secreta"
                  />
                  <p className="text-xs text-muted-foreground">
                    A chave secreta é usada para assinar requisições à API.
                  </p>
                </div>

                {exchange === "binance" && (
                  <div className="flex items-center space-x-2">
                    <Switch
                      id={`${exchange}-testnet`}
                      checked={configs[exchange].testnet}
                      onCheckedChange={(checked) => updateConfig(exchange, "testnet", checked)}
                    />
                    <Label htmlFor={`${exchange}-testnet`}>Usar Testnet</Label>
                  </div>
                )}

                <div className="bg-amber-50 dark:bg-amber-950 p-4 rounded-md">
                  <div className="flex items-start space-x-2">
                    <AlertTriangle className="h-5 w-5 text-amber-500 mt-0.5" />
                    <div>
                      <h4 className="font-medium text-amber-700 dark:text-amber-300">Importante</h4>
                      <p className="text-sm text-amber-600 dark:text-amber-400 mt-1">
                        Suas chaves de API são armazenadas localmente no seu navegador. Nunca compartilhe suas chaves de
                        API com ninguém. Recomendamos criar chaves de API com permissões de leitura apenas para maior
                        segurança.
                      </p>
                    </div>
                  </div>
                </div>

                <div className="flex space-x-2 pt-2">
                  <Button
                    variant="outline"
                    className="flex-1"
                    onClick={() => testConnection(exchange)}
                    disabled={isTestingConnection[exchange]}
                  >
                    {isTestingConnection[exchange] ? (
                      <>
                        <RefreshCw className="h-4 w-4 mr-2 animate-spin" />
                        Testando...
                      </>
                    ) : (
                      <>
                        {connectionStatus[exchange] === true ? (
                          <Check className="h-4 w-4 mr-2 text-green-500" />
                        ) : connectionStatus[exchange] === false ? (
                          <X className="h-4 w-4 mr-2 text-red-500" />
                        ) : null}
                        Testar Conexão
                      </>
                    )}
                  </Button>
                  <Button className="flex-1" onClick={() => saveConfig(exchange)}>
                    Salvar Configuração
                  </Button>
                  <Button variant="destructive" onClick={() => clearConfig(exchange)}>
                    Limpar
                  </Button>
                </div>
              </div>
            </TabsContent>
          ))}
        </Tabs>
      </CardContent>
    </Card>
  )
}
