// Serviço de agendamento de notificações automáticas

import { sendNotification } from "./notification-service"

interface SchedulerConfig {
  enabled: boolean
  frequency: "realtime" | "hourly" | "daily" | "custom"
  customMinutes?: number
  quietHoursStart?: string
  quietHoursEnd?: string
  enableQuietHours?: boolean
}

interface NotificationJob {
  id: string
  type: "signal" | "alert" | "summary" | "market" | "error"
  title: string
  message: string
  scheduled: Date
  sent: boolean
}

// Armazenamento em memória para demonstração
const notificationQueue: NotificationJob[] = []
let schedulerInterval: NodeJS.Timeout | null = null

// Verifica se o horário atual está dentro do período silencioso
function isInQuietHours(quietHoursStart: string, quietHoursEnd: string): boolean {
  const now = new Date()
  const currentHour = now.getHours()
  const currentMinute = now.getMinutes()

  const [startHour, startMinute] = quietHoursStart.split(":").map(Number)
  const [endHour, endMinute] = quietHoursEnd.split(":").map(Number)

  const currentTime = currentHour * 60 + currentMinute
  const startTime = startHour * 60 + startMinute
  const endTime = endHour * 60 + endMinute

  // Verifica se o período silencioso cruza a meia-noite
  if (startTime > endTime) {
    return currentTime >= startTime || currentTime <= endTime
  }

  return currentTime >= startTime && currentTime <= endTime
}

// Inicia o agendador de notificações
export function startNotificationScheduler(config: SchedulerConfig, notificationConfig: any) {
  if (!config.enabled) {
    stopNotificationScheduler()
    return
  }

  // Limpa qualquer intervalo existente
  if (schedulerInterval) {
    clearInterval(schedulerInterval)
  }

  // Define o intervalo com base na frequência configurada
  let intervalMs = 60000 // 1 minuto por padrão

  switch (config.frequency) {
    case "realtime":
      intervalMs = 10000 // 10 segundos para simular "tempo real"
      break
    case "hourly":
      intervalMs = 3600000 // 1 hora
      break
    case "daily":
      intervalMs = 86400000 // 24 horas
      break
    case "custom":
      intervalMs = (config.customMinutes || 30) * 60000
      break
  }

  // Inicia o intervalo para processar a fila de notificações
  schedulerInterval = setInterval(() => {
    processNotificationQueue(config, notificationConfig)
  }, intervalMs)

  console.log(`Agendador de notificações iniciado com intervalo de ${intervalMs / 1000} segundos`)
}

// Para o agendador de notificações
export function stopNotificationScheduler() {
  if (schedulerInterval) {
    clearInterval(schedulerInterval)
    schedulerInterval = null
    console.log("Agendador de notificações parado")
  }
}

// Processa a fila de notificações
async function processNotificationQueue(config: SchedulerConfig, notificationConfig: any) {
  // Verifica se está no período silencioso
  if (
    config.enableQuietHours &&
    config.quietHoursStart &&
    config.quietHoursEnd &&
    isInQuietHours(config.quietHoursStart, config.quietHoursEnd)
  ) {
    console.log("Período silencioso ativo, notificações pausadas")
    return
  }

  const now = new Date()
  const pendingNotifications = notificationQueue.filter((job) => !job.sent && job.scheduled <= now)

  for (const job of pendingNotifications) {
    try {
      const success = await sendNotification(notificationConfig, job.title, job.message, job.type)

      if (success) {
        job.sent = true
        console.log(`Notificação ${job.id} enviada com sucesso`)
      } else {
        console.error(`Falha ao enviar notificação ${job.id}`)
      }
    } catch (error) {
      console.error(`Erro ao processar notificação ${job.id}:`, error)
    }
  }

  // Remove notificações enviadas da fila após 1 hora
  const oneHourAgo = new Date(now.getTime() - 3600000)
  const filteredQueue = notificationQueue.filter((job) => !job.sent || job.scheduled > oneHourAgo)

  // Atualiza a fila
  notificationQueue.length = 0
  notificationQueue.push(...filteredQueue)
}

// Adiciona uma notificação à fila
export function scheduleNotification(
  type: "signal" | "alert" | "summary" | "market" | "error",
  title: string,
  message: string,
  delayMinutes = 0,
): string {
  const id = `notification_${Date.now()}_${Math.random().toString(36).substring(2, 9)}`
  const scheduled = new Date(Date.now() + delayMinutes * 60000)

  notificationQueue.push({
    id,
    type,
    title,
    message,
    scheduled,
    sent: false,
  })

  console.log(`Notificação ${id} agendada para ${scheduled.toLocaleString()}`)
  return id
}

// Cancela uma notificação agendada
export function cancelScheduledNotification(id: string): boolean {
  const initialLength = notificationQueue.length
  const filteredQueue = notificationQueue.filter((job) => job.id !== id || job.sent)

  notificationQueue.length = 0
  notificationQueue.push(...filteredQueue)

  return initialLength !== notificationQueue.length
}

// Obtém todas as notificações agendadas
export function getScheduledNotifications(): NotificationJob[] {
  return [...notificationQueue]
}
