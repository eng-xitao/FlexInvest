"use server"

// Simulação de um banco de dados para armazenar configurações
const configStore = {
  telegram: {
    enabled: false,
    botToken: "",
    chatId: "",
    autoNotify: {
      signals: true,
      alerts: true,
      dailySummary: true,
      marketUpdates: false,
      errorNotifications: true,
    },
    notificationSchedule: {
      frequency: "realtime",
      customMinutes: 30,
      quietHoursStart: "22:00",
      quietHoursEnd: "08:00",
      enableQuietHours: false,
    },
  },
}

export async function saveConfig(configType: string, config: any) {
  // Em um ambiente real, isso salvaria no banco de dados
  configStore[configType] = config

  // Simula um atraso de rede
  await new Promise((resolve) => setTimeout(resolve, 500))

  return { success: true }
}

export async function getConfig(configType: string) {
  // Em um ambiente real, isso buscaria do banco de dados
  // Simula um atraso de rede
  await new Promise((resolve) => setTimeout(resolve, 300))

  return configStore[configType] || null
}
