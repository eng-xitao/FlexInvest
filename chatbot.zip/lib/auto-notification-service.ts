"use server"

import { getConfig } from "./config-service"
import { sendTelegramNotification } from "./notification-service"

// Tipos de eventos que podem gerar notificações
type EventType =
  | "price_alert"
  | "indicator_alert"
  | "buy_signal"
  | "sell_signal"
  | "order_executed"
  | "daily_summary"
  | "market_update"
  | "system_error"

interface NotificationEvent {
  type: EventType
  title: string
  message: string
  data?: any
}

// Função para verificar se deve enviar notificação com base nas configurações
async function shouldSendNotification(eventType: EventType): Promise<boolean> {
  try {
    const config = await getConfig("telegram")

    if (!config || !config.enabled) {
      return false
    }

    // Verificar horário silencioso
    if (config.notificationSchedule.enableQuietHours) {
      const now = new Date()
      const currentHour = now.getHours()
      const currentMinute = now.getMinutes()

      const [startHour, startMinute] = config.notificationSchedule.quietHoursStart.split(":").map(Number)
      const [endHour, endMinute] = config.notificationSchedule.quietHoursEnd.split(":").map(Number)

      const currentTime = currentHour * 60 + currentMinute
      const startTime = startHour * 60 + startMinute
      const endTime = endHour * 60 + endMinute

      // Se o período silencioso cruza a meia-noite
      if (startTime > endTime) {
        if (currentTime >= startTime || currentTime <= endTime) {
          return false
        }
      } else if (currentTime >= startTime && currentTime <= endTime) {
        return false
      }
    }

    // Verificar tipo de evento
    switch (eventType) {
      case "price_alert":
      case "indicator_alert":
        return config.autoNotify.alerts
      case "buy_signal":
      case "sell_signal":
        return config.autoNotify.signals
      case "daily_summary":
        return config.autoNotify.dailySummary
      case "market_update":
        return config.autoNotify.marketUpdates
      case "system_error":
        return config.autoNotify.errorNotifications
      default:
        return true
    }
  } catch (error) {
    console.error("Erro ao verificar configurações de notificação:", error)
    return false
  }
}

// Função para enviar notificação automática
export async function sendAutoNotification(event: NotificationEvent): Promise<{ success: boolean; error?: string }> {
  try {
    // Verificar se deve enviar notificação
    const shouldSend = await shouldSendNotification(event.type)

    if (!shouldSend) {
      return { success: false, error: "Notificação desativada nas configurações" }
    }

    // Obter configurações do Telegram
    const config = await getConfig("telegram")

    if (!config || !config.botToken || !config.chatId) {
      return { success: false, error: "Configurações do Telegram incompletas" }
    }

    // Enviar notificação
    const result = await sendTelegramNotification(config.botToken, config.chatId, event.message)

    // Registrar evento de notificação (em um ambiente real, isso seria salvo em um banco de dados)
    console.log(`Notificação automática enviada: ${event.type} - ${event.title}`)

    return result
  } catch (error) {
    console.error("Erro ao enviar notificação automática:", error)
    return {
      success: false,
      error: error instanceof Error ? error.message : "Erro desconhecido",
    }
  }
}

// Função para simular o envio de notificações automáticas (para demonstração)
export async function simulateAutoNotifications(): Promise<void> {
  // Simular alerta de preço
  await sendAutoNotification({
    type: "price_alert",
    title: "Alerta de Preço",
    message: `🚨 Alerta de Preço - FlexInvest

📊 BTC/USD atingiu $55,000.00
⏰ ${new Date().toLocaleTimeString()}

Configurado em: $55,000.00
Condição: Acima de

🤖 Alerta gerado automaticamente por FlexInvest`,
  })

  // Simular sinal de compra
  await sendAutoNotification({
    type: "buy_signal",
    title: "Sinal de Compra",
    message: `🟢 SINAL DE COMPRA - FlexInvest

📊 Moeda: ETH/USD
💲 Preço Atual: $3,250.75
📈 Variação 1h: +2.3%
✅ Confiabilidade: 78%

🕒 Horário de Entrada: ${new Date().toLocaleTimeString()}
⏳ Expiração: Entrada válida por 3 minutos

📝 Justificativa: RSI saindo da zona de sobrevenda com aumento de volume

🤖 Sinal gerado automaticamente por FlexInvest`,
  })
}
